from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db_conector import lecturers_col, ratings_col, delete_rating_by_id
from bson.objectid import ObjectId
import datetime

lecturer = Blueprint('lecturer', __name__, static_folder='static', static_url_path='/lecturer',
                     template_folder='templates')

@lecturer.route('/lecturer/<lecturer_name>', methods=['GET', 'POST'])
def index(lecturer_name):
    if request.method == 'POST':
        if 'user' not in session:
            flash("יש להתחבר למערכת לביצוע פעולה זו")
            return redirect(url_for('login.index'))

        user = session['user']
        rating = request.form['rating']
        comment = request.form['comment']
        date = datetime.datetime.now().strftime('%d.%m.%Y, %H:%M:%S')

        new_rating = {
            "lecturer_name": lecturer_name,
            "user_id": ObjectId(user['_id']),
            "username": user['username'],
            "rating": int(rating),
            "comment": comment,
            "date": date
        }

        ratings_col.insert_one(new_rating)
        return redirect(url_for('lecturer.index', lecturer_name=lecturer_name))

    lecturer = lecturers_col.find_one({"name": lecturer_name})
    ratings = list(ratings_col.find({"lecturer_name": lecturer_name}))

    average_rating = 0
    if ratings:
        total_rating = sum(r['rating'] for r in ratings)
        average_rating = total_rating / len(ratings)
        average_rating = round(average_rating, 2)  # round to 2 decimal places

    # Ensure photo_url is present, use a generic photo if not
    photo_url = lecturer.get('photo_url', 'img/generic-person.jpg')

    return render_template('lecturer.html', lecturer=lecturer, ratings=ratings, average_rating=average_rating,
                           photo_url=photo_url)

@lecturer.route('/lecturer/<lecturer_name>/delete_rating/<rating_id>', methods=['POST'])
def delete_rating(lecturer_name, rating_id):
    if 'user' not in session:
        flash("יש להתחבר למערכת לביצוע פעולה זו")
        return redirect(url_for('login.index'))

    user_id = session['user']['_id']
    delete_rating_by_id(rating_id, user_id)


    return redirect(url_for('lecturer.index', lecturer_name=lecturer_name))
