document.addEventListener('DOMContentLoaded', function() {
    let selectedRating = 0;
    const stars = document.querySelectorAll('.rating-input img');
    stars.forEach((star, index) => {
        star.addEventListener('mouseover', function() {
            for (let i = 0; i <= index; i++) {
                stars[i].classList.add('hover');
            }
        });
        star.addEventListener('mouseout', function() {
            stars.forEach(s => s.classList.remove('hover'));
        });
        star.addEventListener('click', function() {
            stars.forEach(s => s.classList.remove('active'));
            for (let i = 0; i <= index; i++) {
                stars[i].classList.add('active');
            }
            selectedRating = index + 1;
            document.getElementById('rating').value = selectedRating;
        });
    });

    const newCommentForm = document.getElementById("new-comment-form");

    newCommentForm.addEventListener("submit", (event) => {
        if (selectedRating === 0) {
            event.preventDefault();
            alert("אנא בחר דירוג.");
        } else {
            const date = new Date().toLocaleString('he-IL', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
            document.getElementById('date').value = date;
        }
    });
});
