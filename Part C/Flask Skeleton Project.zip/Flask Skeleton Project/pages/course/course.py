from flask import Blueprint, render_template, request, redirect, url_for, flash
from db_conector import lecturers_col, courses_col

course = Blueprint('course', __name__, static_folder='static', static_url_path='/course', template_folder='templates')

@course.route('/course/<course_name>', methods=['GET'])
def index(course_name):
    course = courses_col.find_one({"name": course_name})

    if course:
        lecturers_info = []
        for lecturer in course['lecturers']:
            lecturer_data = lecturers_col.find_one({'name': lecturer['name']})
            if lecturer_data:
                lecturers_info.append({
                    'name': lecturer['name'],
                    'institution': lecturer['institution'],
                    'link': url_for('lecturer.index', lecturer_name=str(lecturer_data['name'])) if lecturer_data else None
                })
            else:
                lecturers_info.append({
                    'name': lecturer['name'],
                    'institution': lecturer['institution'],
                    'link': None
                })

        return render_template('course.html', course=course, lecturers_info=lecturers_info)
    else:
        flash('הקורס לא נמצא')
        return redirect(url_for('homepage.index'))
