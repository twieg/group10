class User {
    constructor(username, email, password, firstName, lastName, major) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.major = major;
    }
}

const validateForm = () => {
    const username = document.querySelector('input[name="username"]').value.trim();
    const email = document.querySelector('input[name="email"]').value.trim();
    const password = document.querySelector('input[name="password"]').value.trim();
    const confirmPassword = document.querySelector('input[name="confirmPassword"]').value.trim();
    const firstName = document.querySelector('input[name="firstName"]').value.trim();
    const lastName = document.querySelector('input[name="lastName"]').value.trim();
    const major = document.querySelector('select[name="major"]').value.trim();

    if (!isValidUsername(username)) {
        displayError("שם משתמש צריך לכלול לפחות 2 אותיות");
        return null;
    }

    if (!isValidEmail(email)) {
        displayError("כתובת דואר אלקטרוני לא תקינה, הכנס כתובת אחרת");
        return null;
    }

    if (!isValidPassword(password)) {
        displayError("סיסמא צריכה להיות בעלת לפחות 8 תווים, כוללת אות גדולה ומספר");
        return null;
    }

    if (password !== confirmPassword) {
        displayError("הסיסמאות לא תואמות");
        return null;
    }

    if (!isValidName(firstName)) {
        displayError("שם פרטי צריך לכלול לפחות 2 אותיות");
        return null;
    }

    if (!isValidName(lastName)) {
        displayError("שם משפחה צריך לכלול לפחות 2 אותיות");
        return null;
    }

    return new User(username, email, password, firstName, lastName, major);
};

const displayError = (message) => {
    const msg = document.querySelector('.msg');
    msg.innerHTML = message;
    msg.classList.add('error');
    setTimeout(() => {
        msg.innerHTML = '';
        msg.classList.remove('error');
    }, 5000);
};

const isValidUsername = (username) => {
    return /^[A-Za-zא-ת\s]{2,}$/.test(username);
};

const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

const isValidPassword = (password) => {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
    return passwordRegex.test(password);
};

const isValidName = (name) => {
    return /^[A-Za-zא-ת\s]{2,}$/.test(name);
};

const handleSubmit = (event) => {
    event.preventDefault();
    const user = validateForm();
    if (user) {
        const formData = new FormData();
        formData.append('username', user.username);
        formData.append('email', user.email);
        formData.append('password', user.password);
        formData.append('firstName', user.firstName);
        formData.append('lastName', user.lastName);
        formData.append('major', user.major);


        fetch('/register', {
            method: 'POST',
            body: formData,
        })
        .then(response => {
            if (response.ok) {
                alert("Registration successful!");
                document.getElementById("registrationForm").reset();
                window.location.href = "login";
            } else {
                response.json().then(data => {
                    displayError(data.message || "Error during registration");
                });
            }
        })
        .catch(error => {
            displayError("Error during registration: " + error.message);
        });
    }
};

document.getElementById("registrationForm").addEventListener("submit", handleSubmit);
