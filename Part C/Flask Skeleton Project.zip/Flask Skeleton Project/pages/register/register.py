from flask import Blueprint, render_template, request, redirect, url_for, flash
from db_conector import insert_user, users_col

register = Blueprint(
    'register',
    __name__,
    static_folder='static',
    static_url_path='/register',
    template_folder='templates'
)

@register.route('/register', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        try:
            email = request.form['email']
            existing_user = users_col.find_one({'email': email})

            if existing_user:
                flash("כתובת דוא\"ל זו כבר קיימת במערכת. השתמש בכתובת אחרת.")
                return redirect(url_for('register.index'))

            user = {
                "username": request.form['username'],
                "email": email,
                "firstName": request.form['firstName'],
                "lastName": request.form['lastName'],
                "password": request.form['password'],
                "major": request.form['major'],
            }
            insert_user(user)
            flash("משתמש נרשם בהצלחה!")
            return redirect(url_for('login.index'))
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            flash(f"An error occurred: {str(e)}", "danger")
            return redirect(url_for('register.index'))
    return render_template('register.html')
