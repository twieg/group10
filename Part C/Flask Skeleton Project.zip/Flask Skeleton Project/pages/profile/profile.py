from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db_conector import users_col
from bson.objectid import ObjectId

profile = Blueprint('profile', __name__, static_folder='static', static_url_path='/profile', template_folder='templates')

@profile.route('/profile', methods=['GET', 'POST'])
def index():
    if 'user' not in session:
        flash("יש להתחבר למערכת לביצוע פעולה זו")
        return redirect(url_for('login.index'))

    user_id = session['user']['_id']

    success_message = None

    if request.method == 'POST':
        updated_user = {
            "email": request.form['email'],
            "username": request.form['username'],
            "firstName": request.form['firstName'],
            "lastName": request.form['lastName'],
            "major": request.form['major'],
            "password": request.form['password']
        }
        users_col.update_one({"_id": ObjectId(user_id)}, {"$set": updated_user})
        success_message = "הפרופיל עודכן בהצלחה"

    user = users_col.find_one({"_id": ObjectId(user_id)})
    return render_template('profile.html', user=user, success_message=success_message)
