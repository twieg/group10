from flask import Blueprint

page_error_handlers = Blueprint('page_error_handlers', __name__)

@page_error_handlers.app_errorhandler(404)
def handle_404(error):
    return "Page not found", 404

@page_error_handlers.app_errorhandler(500)
def handle_500(error):
    return "Internal server error", 500
