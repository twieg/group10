from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from db_conector import forum_col, get_forum_questions_sorted_by_responses, get_forum_questions_sorted_by_date

forum = Blueprint('forum', __name__, static_folder='static', static_url_path='/forum', template_folder='templates')

@forum.route('/forum', methods=['GET', 'POST'])
def index():
    sort_by = request.args.get('sort_by', 'date')

    if sort_by == 'responses':
        questions = get_forum_questions_sorted_by_responses()
    else:
        questions = get_forum_questions_sorted_by_date()

    return render_template('forum.html', questions=questions, sort_by=sort_by)

@forum.route('/forum', methods=['POST'])
def add_question():
    if 'user' not in session:
        flash("יש להתחבר למערכת לביצוע פעולה זו")
        return redirect(url_for('login.index'))

    user = session['user']
    question = request.json['question']
    date = request.json['date']

    new_question = {
        "author": user['username'],
        "question": question,
        "date": date,
        "responses": 0,
        "comments": []
    }

    forum_col.insert_one(new_question)
    return jsonify({"success": True, "author": user['username'], "question": question, "date": date})
