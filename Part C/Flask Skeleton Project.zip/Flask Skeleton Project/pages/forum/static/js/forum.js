document.addEventListener("DOMContentLoaded", () => {
    const questionForm = document.getElementById("new-question-form");
    const sortBySelect = document.getElementById("sort-by");

    if (questionForm) {
        questionForm.addEventListener("submit", (event) => {
            event.preventDefault();

            const question = document.getElementById("question").value.trim();
            const date = new Date().toLocaleString('he-IL', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            });

            if (question) {
                fetch('/forum', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ question, date }),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        questionForm.reset();
                        window.location.href = "/forum";
                    } else {
                        alert("Failed to add question.");
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            }
        });
    }

    if (sortBySelect) {
        sortBySelect.addEventListener("change", () => {
            const sortBy = sortBySelect.value;
            window.location.href = `/forum?sort_by=${sortBy}`;
        });
    }
});
