from flask import Blueprint, render_template
from db_conector import events_col

events = Blueprint('events', __name__, static_folder='static', static_url_path='/events', template_folder='templates')

@events.route('/events', methods=['GET'])
def index():
    all_events = list(events_col.find())
    return render_template('events.html', events=all_events)

