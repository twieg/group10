from flask import Blueprint, request, redirect, url_for, flash, render_template, jsonify
from db_conector import lecturers_col, courses_col
import re

homepage = Blueprint('homepage', __name__, static_folder='static', static_url_path='/homepage', template_folder='templates')

@homepage.route('/')
@homepage.route('/homepage')
def index():
    return render_template('homepage.html')

@homepage.route('/search', methods=['GET'])
def search():
    query = request.args.get('q', '').strip().lower()
    if not query:
        return jsonify({'success': False, 'message': 'אנא הכנס שם מרצה או קורס לחיפוש.'})

    lecturer = lecturers_col.find_one({'name': re.compile(query, re.IGNORECASE)})
    if lecturer:
        return jsonify({'success': True, 'url': url_for('lecturer.index', lecturer_name=str(lecturer['name']))})

    course = courses_col.find_one({'name': re.compile(query, re.IGNORECASE)})
    if course:
        return jsonify({'success': True, 'url': url_for('course.index', course_name=str(course['name']))})

    return jsonify({'success': False, 'message': 'לא נמצא מרצה או קורס בשם זה. אנא נסה שנית.'})
