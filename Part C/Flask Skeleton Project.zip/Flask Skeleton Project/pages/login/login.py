from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from db_conector import users_col

login = Blueprint(
    'login',
    __name__,
    static_folder='static',
    static_url_path='/login',
    template_folder='templates'
)

@login.route('/login', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        try:
            email = request.json['email']
            password = request.json['password']
            print(f"Received login request with email: {email} and password: {password}")

            user = users_col.find_one({'email': email, 'password': password})
            print(f"User found: {user}")

            if user:
                session['user'] = {
                    'email': user['email'],
                    'username': user['username'],
                    '_id': str(user['_id'])
                }
                return jsonify({'message': 'Login successful'}), 200
            else:
                return jsonify({'message': 'Invalid email or password'}), 401
        except Exception as e:
            print(f"Error during login: {str(e)}")
            return jsonify({'message': 'Internal server error'}), 500
    return render_template('login.html')
