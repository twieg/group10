document.addEventListener("DOMContentLoaded", () => {
    const signInForm = document.querySelector(".form");

    signInForm.addEventListener("submit", (event) => {
        event.preventDefault();

        const email = document.querySelector('input[name="email"]').value.trim();
        const password = document.querySelector('input[name="password"]').value.trim();

        if (!isValidEmail(email)) {
            displayError("כתובת דואר אלקטרוני לא תקינה, הכנס כתובת אחרת");
            return;
        }

        if (!isValidPassword(password)) {
            displayError("סיסמא צריכה להיות בעלת לפחות 8 תווים, כוללת אות גדולה ומספר");
            return;
        }

        fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        })
        .then(response => {
            if (response.ok) {
                window.location.href = "/homepage";
            } else {
                response.json().then(data => {
                    displayError(data.message || "Error during login");
                });
            }
        })
        .catch(error => {
            displayError("Error during login: " + error.message);
        });
    });
});

const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

const isValidPassword = (password) => {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
    return passwordRegex.test(password);
};

const displayError = (message) => {
    const msg = document.querySelector('.msg');
    msg.innerHTML = message;
    msg.classList.add('error');
    setTimeout(() => {
        msg.innerHTML = '';
        msg.classList.remove('error');
    }, 5000);
};
