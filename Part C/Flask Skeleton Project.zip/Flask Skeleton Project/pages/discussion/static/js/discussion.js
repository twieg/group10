document.getElementById('new-comment-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const form = event.target;
    const questionId = form.getAttribute('data-question-id');
    const comment = form.comment.value;

    fetch(`/forum/${questionId}/comment`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            comment: comment,
            date: new Date().toLocaleString()
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const commentList = document.getElementById('comment-list');
            const newComment = document.createElement('li');
            newComment.classList.add('comment');
            newComment.innerHTML = `
                <div class="comment-header">
                    <span class="comment-author">${data.author}</span>
                    <span class="comment-date">${data.date}</span>
                    </form>
                </div>
                <p class="comment-text">${data.comment}</p>
            `;
            commentList.appendChild(newComment);
            form.reset();
        } else {
            alert('יש להתחבר למערכת לביצוע פעולה זו');
        }
    });
});
