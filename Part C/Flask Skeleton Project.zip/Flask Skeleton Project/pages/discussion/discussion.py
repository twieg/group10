from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for
from bson.objectid import ObjectId
from db_conector import forum_col

discussion = Blueprint('discussion', __name__, static_folder='static', static_url_path='/discussion',
                       template_folder='templates')


@discussion.route('/forum/<forum_question>', methods=['GET'])
def index(forum_question):
    question = forum_col.find_one({"question": forum_question})
    return render_template('discussion.html', question=question)


@discussion.route('/forum/<string:forum_question>/comment', methods=['POST'])
def add_comment(forum_question):
    data = request.get_json()
    comment = data.get('comment')
    date = data.get('date')

    if 'user' in session:
        author = session['user']['username']
        new_comment = {
            "_id": ObjectId(),
            "author": author,
            "comment": comment,
            "date": date
        }
        forum_col.update_one({"question": forum_question},
                             {"$push": {"comments": new_comment}, "$inc": {"responses": 1}})

        return jsonify({"success": True, "author": author, "comment": comment, "date": date, "comment_id": str(new_comment["_id"])})
    else:
        return jsonify({"success": False}), 401

