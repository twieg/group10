import os
import certifi
from bson import ObjectId
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()
uri = os.environ.get('DB_URI')
client = MongoClient(uri, tls=True, tlsCAFile=certifi.where(), server_api=ServerApi('1'))
mydatabase = client['sample_mflix']

# Define collections
users_col = mydatabase['users']
lecturers_col = mydatabase['Lecturer']
courses_col = mydatabase['Course']
events_col = mydatabase['Events']
forum_col = mydatabase['Forum']
ratings_col = mydatabase['Rating']

# Create necessary functions
def get_list_of_users():
    return list(users_col.find())

def insert_user(user_dict):
    try:
        users_col.insert_one(user_dict)
        print("User inserted:", user_dict)
    except Exception as e:
        print("Error inserting user:", e)
        raise

def get_list_of_lecturers():
    return list(lecturers_col.find())

def insert_lecturer(lecturer_dict):
    lecturers_col.insert_one(lecturer_dict)

def get_list_of_courses():
    return list(courses_col.find())

def insert_course(course_dict):
    courses_col.insert_one(course_dict)

def get_list_of_events():
    return list(events_col.find())

def insert_event(event_dict):
    events_col.insert_one(event_dict)

def get_list_of_forum():
    return list(forum_col.find())

def insert_forum(forum_dict):
    forum_col.insert_one(forum_dict)

def get_list_of_rating():
    return list(ratings_col.find())

def insert_rating(rating_dict):
    ratings_col.insert_one(rating_dict)


def get_username_by_id(user_id):
    user = users_col.find_one({"_id": ObjectId(user_id)}, {"username": 1})
    return user["username"] if user else None

# Questions sorted by number of responses
def get_forum_questions_sorted_by_responses():
    return list(forum_col.find().sort("responses", -1))

# Questions sorted by date
def get_forum_questions_sorted_by_date():
    return list(forum_col.find().sort("date", -1))

def delete_rating_by_id(rating_id, user_id):
    result = ratings_col.delete_one({"_id": ObjectId(rating_id), "user_id": ObjectId(user_id)})
    return result.deleted_count > 0





