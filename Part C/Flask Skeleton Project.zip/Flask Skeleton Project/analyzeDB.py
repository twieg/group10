from db_conector import (
    get_list_of_users,
    get_list_of_lecturers,
    get_list_of_courses,
    get_list_of_events,
    get_list_of_forum,
    get_list_of_rating
)

def print_collection(name, collection):
    print(f"Collection: {name}")
    for document in collection:
        print(document)
    print("\n")

def print_user_activity_rankings(collection):
    print("User Activity Rankings")
    for document in collection:
        print(f"Username: {document['username']}, Total Activity: {document['total_activity_count']}")
    print("\n")

def analyze_db():
    #print collections
    print_collection("users", get_list_of_users())
    print_collection("Lecturer", get_list_of_lecturers())
    print_collection("Course", get_list_of_courses())
    print_collection("Events", get_list_of_events())
    print_collection("Forum", get_list_of_forum())
    print_collection("Rating", get_list_of_rating())


if __name__ == "__main__":
    analyze_db()
