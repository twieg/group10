import os

class Config:
    FLASK_ENV = 'development'
    DEBUG = True
    FLASK_RUN_HOST = '127.0.0.1'
    FLASK_RUN_PORT = 5000
    SECRET_KEY = os.urandom(24)
    DB_URI = os.environ.get('DB_URI')

class ProductionConfig(Config):
    FLASK_ENV = 'production'
    DEBUG = False

class DevelopmentConfig(Config):
    DEBUG = True

config_by_name = dict(
    dev=DevelopmentConfig,
    prod=ProductionConfig
)
