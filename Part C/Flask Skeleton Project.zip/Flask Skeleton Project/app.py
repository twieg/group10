import os
from flask import Flask
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

DB_URI = os.environ.get('DB_URI')

# Create a new client and connect to the server
client = MongoClient(DB_URI, server_api=ServerApi('1'))

# App setup
app = Flask(__name__)
app.config.from_pyfile('settings.py')
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', b'+\xcb\x0f\xa0\x02\x12\xd8\x16\xd4w\xb8i\xac\xd0?I')
def dict_merge(d1, d2):
    d = d1.copy()
    d.update(d2)
    return d

@app.context_processor
def utility_processor():
    return dict(dict_merge=dict_merge)


###### Pages
## Homepage
from pages.homepage.homepage import homepage
app.register_blueprint(homepage)

## register
from pages.register.register import register
app.register_blueprint(register)

## Events
from pages.events.events import events
app.register_blueprint(events)

## Profile
from pages.profile.profile import profile
app.register_blueprint(profile)

## Login
from pages.login.login import login
app.register_blueprint(login)

## Logout
from pages.logout.logout import logout
app.register_blueprint(logout)

## Lecturer
from pages.lecturer.lecturer import lecturer
app.register_blueprint(lecturer)

## Course
from pages.course.course import course
app.register_blueprint(course)

## Discussion
from pages.discussion.discussion import discussion
app.register_blueprint(discussion)

## Forum
from pages.forum.forum import forum
app.register_blueprint(forum)

## Page error handlers
from pages.page_error_handlers.page_error_handlers import page_error_handlers
app.register_blueprint(page_error_handlers)

###### Components
## Main menu
from components.main_menu.main_menu import main_menu
app.register_blueprint(main_menu)

if __name__ == "__main__":
     app.run()

